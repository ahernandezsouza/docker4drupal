<?php

/**
 * @file
 * A cached plugin object that tests inheritance including.
 */

class ctoolsCachedPluginArray {}
